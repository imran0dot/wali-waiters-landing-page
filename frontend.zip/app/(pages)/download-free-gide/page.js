import React from 'react';
import LeadMagnetForm from '../../../components/LeadMannagment';

const Page = () => (

  <div className="bg-primary-black overflow-hidden min-h-screen">
    <div className="relative">
      <LeadMagnetForm />
      <div className="gradient-03 z-0" />
    </div>
  </div>
);

export default Page;
